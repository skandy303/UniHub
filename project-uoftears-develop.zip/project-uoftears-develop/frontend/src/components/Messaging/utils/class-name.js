export function joinClassNames(classNames) {
  return classNames.filter(Boolean).join(" ");
}
