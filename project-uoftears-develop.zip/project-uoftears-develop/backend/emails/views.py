from django.shortcuts import render
from django.core.mail import send_mail
from rest_framework.views import APIView
from rest_framework.response import Response

# def send_email(subject, body, from_email, to_emails):
#     context = ssl.create_default_context(cafile=certifi.where())
#     message = Mail(
#     from_email=from_email,
#     to_emails=to_emails,
#     subject='Sending with Twilio SendGrid is Fun',
#     html_content='<strong>and easy to do anywhere, even with Python</strong>')
#     try:
#         sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
#         response = sg.send(message)
#         print(response.status_code)
#         print(response.body)
#         print(response.headers)
#     except Exception as e:
#         print(e.message)
class EmailView(APIView):
    def get(self, request):
        try:
            print(
                send_mail(
                    "something",
                    "this is the body",
                    "s.vecham@mail.utoronto.ca",
                    ["skandan.vecham@hotmail.com"],
                    return_path=True,
                )
            )
        except Exception as e:
            print(e.message)
        return Response({"details": "worked"}, status=200)
        # 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
